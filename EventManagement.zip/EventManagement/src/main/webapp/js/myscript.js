function formValidation()                                    
{ 
    var username = document.forms["userform"]["username"];               
    var password= document.forms["userform"]["password"];    
    var fname= document.forms["userform"]["fname"];  
    var lname=  document.forms["userform"]["lname"];  
    var email= document.forms["userform"]["email"];  
    var age= document.forms["userform"]["age"];  
    var gender= document.forms["userform"]["gender"]; 
    var mobile= document.forms["userform"]["mobile"]; 
   
    if (username.value == "")                                  
    { 
        window.alert("Please enter your username."); 
        username.focus(); 
        return false; 
    } 
    var username_len = username.value.length;
	if (username_len == 0 || username_len>16|| username_len< 5)
	{alert("User Id should not be empty / length be between 5 to 16");
	username.focus();
	return false;
	}
    
    if (password.value == "")                               
    { 
        window.alert("Please enter your password."); 
        password.focus(); 
        return false; 
    } 
   
    var password_len = password.value.length;
    if (password_len == 0 ||password_len>16 || password_len<8)
    {
    alert("Password should not be empty / length be between 8 to 16 ");
    password.focus();
    return false;
    }   
    
    if (fname.value == "")                                   
    { 
        window.alert("Please enter a valid first name."); 
        fname.focus(); 
        return false; 
    } 
    var letters = /^[A-Za-z]+$/;
    if(fname.value.match(letters))
    {
    return true;
    }
    else
    {
    alert('First Name must have alphabet characters only');
    fname.focus();
    return false;
    }
    
    if (lname.value == "")                           
    { 
        window.alert("Please enter your last name."); 
        lname.focus(); 
        return false; 
    }
    
    if(lname.value.match(letters))
    {
    return true;
    }
    else
    {
    alert('last name must have alphabet characters only');
    lname.focus();
    return false;
    }
    
    if (email.value == "")                        
    { 
        window.alert("Please enter your email"); 
        email.focus(); 
        return false; 
    } 
   
    if (age.value="")                  
    { 
        alert("Please enter your age"); 
       age.focus(); 
        return false; 
    } 
   
    if (gender.value="")                  
    { 
        alert("Please enter your gender"); 
        gender.focus(); 
        return false; 
    } 
   
    if (mobile.value="")                  
    { 
        alert("Please enter your mobile Number"); 
        mobile.focus(); 
        return false; 
    } 
    var l=mobile.value.length;
    if (l!=10)                  
    { 
        alert("Please enter Valid mobile number"); 
        mobile.focus(); 
        return false; 
    } 
   
    return true; 
}