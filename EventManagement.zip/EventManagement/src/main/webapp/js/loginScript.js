/**
 * 
 */

function validateLoginForm() 
{

	var username = document.forms["loginpage"]["username"].value;
	var password = document.forms["loginpage"]["password"].value;
	var formSubmittionStatus = true;
	if(password.length<8||username=="")
	{
		formSubmittionStatus = false;
	}
	else
		{
		
		}
	if (!formSubmittionStatus ) 
	{
		alert("Enter a valid username and password"+"\n"+"Password should be atleast 8 characters long");
	}
	else 
	{
		
		alert("Form validation success.....");
		
	}

	return formSubmittionStatus;
	
	
	
	}