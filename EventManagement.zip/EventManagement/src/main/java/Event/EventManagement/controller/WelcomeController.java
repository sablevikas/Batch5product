package Event.EventManagement.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import Event.EventManagement.pojo.UserPojo;
import Event.EventManagement.service.UserService;


@Controller
public class WelcomeController {

	@Autowired
	private UserService userService;
	
	@GetMapping("/")
	String welcomePage() {
		
		return "welcome";
	}
	
	@GetMapping("/showUserForm")
	String showUserForm(ModelMap model) {
		model.addAttribute("userPojo", new UserPojo());
		return "userForm";
	}
	
	@PostMapping(value = "/registerUser")
	public String registerUser(@ModelAttribute("userPojo") UserPojo c) {

		System.out.println(c.getFname());

		userService.save(c);

		return "redirect:regSuccess";
	}
	
	@GetMapping("/regSuccess")
	String RegSuccess(ModelMap model) {
		model.addAttribute("reg","Registered Successfully");
		return "welcome";
	}
	
	@GetMapping(value = "/listUser")
	public String listUser(ModelMap model) {

		List<UserPojo> userPojoList = userService.list();
		model.addAttribute("userPojoListObj", userPojoList);
		model.addAttribute("userPojo", new UserPojo());
		return "showUserList";
	}
	

	@GetMapping(value = "/showEditForm")
	public String editUser(@RequestParam int id, ModelMap model) {

		System.out.println("Value passed com id ..." + id);
		UserPojo userPojo = userService.get(id);
		model.addAttribute("userPojo", userPojo);

		return "editUserDetails";
	}

	@PostMapping(value ="/editUserDetails")
	public String editUser(@ModelAttribute("userPojo") UserPojo c) {

		userService.update(c);

		return "redirect:listUser";
	}
	@GetMapping(value = "/deleteUser")
	public String deleteUser(@RequestParam int id) {

		userService.deleteUser(id);

		return "redirect:listUser";
	}
	
	@GetMapping("/login")
	public String LogIn(ModelMap model) {
		model.addAttribute("userPojo", new UserPojo());
		return "login";
	}
	
	@PostMapping("/validateLogin")
	public String ValidateLogin(@ModelAttribute("userPojo") UserPojo c) {
		if(userService.validateLogin(c)==true) {
			return "redirect:success";
		}else {
			return "redirect:fail";	
		}
	}
	@GetMapping("/success")
	public String Success(ModelMap model) {
		model.addAttribute("success","Log in Successfully");
		return "welcome";
	}
	@GetMapping("/fail")
	public String Fail(ModelMap model) {
		model.addAttribute("fail","Log in Failed");
		return "welcome";
	}

	// searchBYUserName
		@PostMapping(value = "/searchBYUserName")
		public String searchBYUserName(@Valid @ModelAttribute("userPojo") UserPojo c,BindingResult br,
				ModelMap model) {


			List<UserPojo> userPojoList = userService.findByUserName(c.getFname().trim());

			model.addAttribute("userPojoListObj", userPojoList);

			return "showUserList";
		}

}
