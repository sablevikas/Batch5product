package Event.EventManagement.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import Event.EventManagement.entity.User;
import Event.EventManagement.pojo.UserPojo;
import Event.EventManagement.repository.UserRepository;





@Service("userService")
@Transactional
public class UserServiceImpl implements UserService{
	

	
	@Autowired
	private UserRepository userRepository;
	

	@Override
	public UserPojo save(UserPojo userPojo) {
		System.out.println("User..." + userPojo.getFname());

		User user= new User();
		user.setUsername(userPojo.getUsername());
		user.setPassword(userPojo.getPassword());
		user.setFname(userPojo.getFname());
		user.setLname(userPojo.getLname());
		user.setEmail(userPojo.getEmail());
		user.setAge(userPojo.getAge());
		user.setGender(userPojo.getGender());
		user.setMobile(userPojo.getMobile());
		userRepository.save(user);

		userPojo.setId(user.getId());

		return userPojo;
	}

	@Override
	public List<UserPojo> list() {
		List<UserPojo> userPojoList = new ArrayList<UserPojo>();

		List<User> userList = userRepository.findAll();

		for (User user : userList) {
			UserPojo userPojo = new UserPojo();
			userPojo.setUsername(user.getUsername());
			userPojo.setId(user.getId());
			userPojo.setFname(user.getFname());
			userPojo.setLname(user.getLname());
			userPojo.setEmail(user.getEmail());
			userPojo.setAge(user.getAge());
			userPojo.setGender(user.getGender());
			userPojo.setMobile(user.getMobile());
			userPojoList.add(userPojo);
			System.out.println(user.getUsername());
		}

		return userPojoList;
	}

	@Override
	public UserPojo get(int userId) {

		User user =userRepository.getOne(userId);

		UserPojo userPojo = new UserPojo();
		userPojo.setUsername(user.getUsername());
		userPojo.setId(user.getId());
		userPojo.setFname(user.getFname());
		userPojo.setLname(user.getLname());
		userPojo.setEmail(user.getEmail());
		userPojo.setAge(user.getAge());
		userPojo.setGender(user.getGender());
		userPojo.setMobile(user.getMobile());
		return userPojo;
	}

	@Override
	public void update(UserPojo userPojo) {

		User user = new User();
		user.setId(userPojo.getId());
		user.setUsername(userPojo.getUsername());
		user.setPassword(userPojo.getPassword());
		user.setFname(userPojo.getFname());
		user.setLname(userPojo.getLname());
		user.setEmail(userPojo.getEmail());
		user.setAge(userPojo.getAge());
		user.setGender(userPojo.getGender());
		user.setMobile(userPojo.getMobile());
		userRepository.save(user);
		
	}

	@Override
	public void deleteUser(int userId) {
		userRepository.deleteById(userId);
	}

	@Override
	public boolean validateLogin(UserPojo userPojo) {
		String userEnter=userPojo.getUsername();
		String passEnter=userPojo.getPassword();
		
		List<User> userList = userRepository.findAll();
		
		for (User user : userList) {
		String userDatabase=user.getUsername();
		String passDatabase=user.getPassword();
		
		if((userEnter.equals(userDatabase))&&(passEnter.equals(passDatabase))) {
		return true;
		}
		}
			return false;
	}

	
	
	@Override
	public List<UserPojo> findByUserName(String fname) {
		
		List<UserPojo> userPojoList = new ArrayList<UserPojo>();

		List<User> userList = userRepository.findByFnameLike(fname);

		
		for (User user : userList) {
			UserPojo userPojo = new UserPojo();
			userPojo.setUsername(user.getUsername());
			userPojo.setId(user.getId());
			userPojo.setFname(user.getFname());
			userPojo.setLname(user.getLname());
			userPojo.setEmail(user.getEmail());
			userPojo.setAge(user.getAge());
			userPojo.setGender(user.getGender());
			userPojo.setMobile(user.getMobile());
			userPojoList.add(userPojo);
			System.out.println(user.getFname());
		}

		return userPojoList;

	}
	
}
