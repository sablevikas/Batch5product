package Event.EventManagement.service;

import java.util.List;

import Event.EventManagement.entity.User;
import Event.EventManagement.pojo.UserPojo;


public interface UserService {

	UserPojo save(UserPojo userPojo);

	List<UserPojo> list();

	UserPojo get(int userId);
	
	void update(UserPojo userPojo);

	void deleteUser(int userId);
	
	boolean validateLogin(UserPojo userPojo);
	
	List<UserPojo> findByUserName(String fname);
	
}
